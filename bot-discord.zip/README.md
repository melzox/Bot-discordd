# Bot Discord

Un simple bot Discord qui répond `Pong!` quand on écrit `!ping`.